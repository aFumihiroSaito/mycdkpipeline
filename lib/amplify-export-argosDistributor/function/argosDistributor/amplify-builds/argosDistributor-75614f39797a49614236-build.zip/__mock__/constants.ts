export const requestContext = {
  stage: 'dev',
}

export const soracomHeaders = {
  'x-soracom-imei': '354734101017248',
  'x-soracom-imsi': '440103230996261',
  'x-soracom-signature':
    'bc85e1d466204fa6bb77f2ba20feeffa9929ad051c6450191279ee9de77e3643',
  'x-soracom-signature-version': '20151001',
  'x-soracom-timestamp': '1624346114167',
}

export const pathParameters = {
  tenantId: 'g_test',
}

export const gpsMultiUnitBody = JSON.stringify({
  payload:
    'eyJsYXQiOjM1LjY5OTI3OCwibG9uIjoxMzkuNzc1MDY1LCJiYXQiOi0xLCJycyI6NCwidGVtcCI6MzQuNSwiaHVtaSI6MzguOSwieCI6bnVsbCwieSI6bnVsbCwieiI6bnVsbCwidHlwZSI6MH0=',
})
