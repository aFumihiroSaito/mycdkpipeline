import context from 'aws-lambda-mock-context'
import { grooveNautsHandler } from '../../handler/grooveNauts'
import * as http from '../../lib/http'
import {
  gpsMultiUnitBody,
  requestContext,
  pathParameters,
  soracomHeaders,
} from '../../__mock__/constants'

jest.mock('../../lib/http')

describe('grooveNautsHandler Input/Output', (): void => {
  test('valid request.', async () => {
    const inputEvent: any = {
      requestContext,
      headers: soracomHeaders,
      pathParameters,
      body: gpsMultiUnitBody,
    }

    const postMock = (http.post as jest.Mock).mockResolvedValue({
      status: 200,
      body: JSON.stringify({}),
    })

    // request handler
    const response = await grooveNautsHandler(inputEvent, context(), () => null)

    expect(postMock.mock.calls.length).toBe(2)

    // test response
    const expected = {
      statusCode: 200,
      body: JSON.stringify({}),
    }

    expect(response).toEqual(expected)
  })

  test('invalid tenant_id request.', async () => {
    const inputEvent: any = {
      requestContext,
      headers: soracomHeaders,
      pathParameters: {
        tenantId: null,
      },
      body: gpsMultiUnitBody,
    }

    // request handler
    const response = await grooveNautsHandler(inputEvent, context(), () => null)

    // test response
    const expected = {
      statusCode: 400,
      body: JSON.stringify({ message: 'Bad request.' }),
    }

    expect(response).toEqual(expected)
  })
})
