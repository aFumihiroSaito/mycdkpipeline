const request = require('supertest')
const app = require('../../app.js')

afterEach(() => {
  return app && app.close()
})

describe('GET /admin/connections', () => {
  test(`returns 200`, async () => {
    const res = await request(app).get(`/admin/connections`)
    expect(res.statusCode).toBe(200)
    expect(res.text).toBe(JSON.stringify({ v2: 0 }))
  })
})
