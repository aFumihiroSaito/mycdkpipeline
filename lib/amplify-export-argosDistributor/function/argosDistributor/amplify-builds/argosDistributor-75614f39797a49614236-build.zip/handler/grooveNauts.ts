import { APIGatewayEvent, APIGatewayProxyHandler } from 'aws-lambda'

import { argosSoracomRequestHeader, sendToArgosSoracom } from '../lib/argos'
import { distributorRequestBody, sendToDistributor } from '../lib/distributor'

const grooveNautsHandler: APIGatewayProxyHandler = async (
  event: APIGatewayEvent
) => {
  const stage = event.requestContext.stage as 'dev' | 'prod'
  const headers = event.headers
  const tenantId = event.pathParameters && event.pathParameters.tenantId
  const body = event.body
  // const valid = validateHash(headers)
  const parsedBody = body && distributorRequestBody(headers, body)
  console.log(`stage: ${stage}`)

  if (!tenantId || !body || !parsedBody) {
    return {
      statusCode: 400,
      body: JSON.stringify({ message: 'Bad request.' }),
    }
  }

  const resArgos = await sendToArgosSoracom(
    argosSoracomRequestHeader(headers),
    tenantId,
    body,
    stage
  )
  console.log(resArgos)

  const resDistributor = await sendToDistributor({}, parsedBody)
  console.log(resDistributor)

  const response = {
    statusCode: 200,
    body: JSON.stringify({}),
  }
  return response
}
export { grooveNautsHandler }
