"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
exports.__esModule = true;
exports.sigfoxHandler = void 0;
var sigfox_1 = require("../lib/sigfox");
var argos_1 = require("../lib/argos");
var aws_1 = require("../lib/aws");
var sigfoxHandler = function (event) { return __awaiter(void 0, void 0, void 0, function () {
    var stage, tenantId, body, sigfoxRequestBody, data, type, parameters, apiKey, headers, argosRequestbody, sigfoxBLEData, sigfoxGPSData, failedData, resArgos, response;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                stage = event.requestContext.stage;
                tenantId = event.pathParameters && event.pathParameters.tenantId;
                body = event.body;
                console.log("stage: " + stage);
                if (!tenantId || !body) {
                    return [2 /*return*/, {
                            statusCode: 400,
                            body: JSON.stringify({ message: 'Bad request.' })
                        }];
                }
                sigfoxRequestBody = JSON.parse(body);
                data = sigfoxRequestBody.data;
                type = data.substr(0, 2);
                if (type !== '1f' && type !== '8f' && type !== '0f') {
                    return [2 /*return*/, {
                            statusCode: 200,
                            body: JSON.stringify({})
                        }];
                }
                console.log("Data payload: " + data);
                return [4 /*yield*/, aws_1.getSigfoxAPIKey()];
            case 1:
                parameters = _a.sent();
                apiKey = parameters[0].Value || 'nekonekoneko';
                headers = {
                    'x-access-device-id': sigfoxRequestBody.device,
                    'x-access-api-key': apiKey
                };
                argosRequestbody = null;
                if (type === '8f') {
                    sigfoxBLEData = sigfox_1.parseBLEData(data);
                    if (sigfoxBLEData) {
                        argosRequestbody = {
                            type: 2,
                            bat: sigfoxBLEData.bat,
                            uuid: 'E02CC25E00494185832C3A65DB755D01',
                            major: sigfoxBLEData.major,
                            minor: sigfoxBLEData.minor,
                            rssi: sigfoxBLEData.rssi,
                            timestamp: sigfoxRequestBody.time
                        };
                    }
                }
                else {
                    if (type === '1f') {
                        sigfoxGPSData = sigfox_1.parseGPSData(data);
                        argosRequestbody = {
                            type: 1,
                            lat: sigfoxGPSData.lat,
                            lon: sigfoxGPSData.lng,
                            bat: sigfoxGPSData.bat,
                            pdop: sigfoxGPSData.pdop,
                            timestamp: sigfoxRequestBody.time
                        };
                    }
                    else {
                        failedData = sigfox_1.parseFailedData(data);
                        argosRequestbody = {
                            type: 1,
                            lat: sigfoxRequestBody.computedLocation.lat,
                            lon: sigfoxRequestBody.computedLocation.lng,
                            bat: failedData.bat,
                            timestamp: sigfoxRequestBody.time,
                            source: sigfoxRequestBody.computedLocation.source
                        };
                    }
                }
                if (!argosRequestbody) return [3 /*break*/, 3];
                return [4 /*yield*/, argos_1.sendToArgosSigfox(headers, tenantId, argosRequestbody, stage)];
            case 2:
                resArgos = _a.sent();
                console.log(resArgos);
                _a.label = 3;
            case 3:
                response = {
                    statusCode: 200,
                    body: JSON.stringify({})
                };
                return [2 /*return*/, response];
        }
    });
}); };
exports.sigfoxHandler = sigfoxHandler;
