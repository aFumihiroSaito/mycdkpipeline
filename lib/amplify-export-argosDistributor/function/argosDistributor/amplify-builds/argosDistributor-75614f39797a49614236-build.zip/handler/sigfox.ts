import { APIGatewayEvent, APIGatewayProxyHandler } from 'aws-lambda'
import {
  parseBLEData,
  parseFailedData,
  parseGPSData,
  SigfoxRequestBody,
} from '../lib/sigfox'

import {
  ArgosSigfoxGPSRequestBody,
  ArgosSigfoxRequestHeader,
  ArgosSigfoxBLERequestBody,
  sendToArgosSigfox,
} from '../lib/argos'
import { getSigfoxAPIKey } from '../lib/aws'

const sigfoxHandler: APIGatewayProxyHandler = async (
  event: APIGatewayEvent
) => {
  const stage = event.requestContext.stage as 'dev' | 'prod'
  const tenantId = event.pathParameters && event.pathParameters.tenantId
  const body = event.body
  console.log(`stage: ${stage}`)

  if (!tenantId || !body) {
    return {
      statusCode: 400,
      body: JSON.stringify({ message: 'Bad request.' }),
    }
  }

  const sigfoxRequestBody: SigfoxRequestBody = JSON.parse(body)

  const data = sigfoxRequestBody.data
  const type = data.substr(0, 2)

  if (type !== '1f' && type !== '8f' && type !== '0f') {
    return {
      statusCode: 200,
      body: JSON.stringify({}),
    }
  }
  console.log(`Data payload: ${data}`)

  const parameters = await getSigfoxAPIKey()
  const apiKey = parameters[0].Value || 'nekonekoneko'

  const headers: ArgosSigfoxRequestHeader = {
    'x-access-device-id': sigfoxRequestBody.device,
    'x-access-api-key': apiKey,
  }

  let argosRequestbody:
    | ArgosSigfoxGPSRequestBody
    | ArgosSigfoxBLERequestBody
    | null = null

  if (type === '8f') {
    const sigfoxBLEData = parseBLEData(data)
    if (sigfoxBLEData) {
      argosRequestbody = {
        type: 2,
        bat: sigfoxBLEData.bat,
        uuid: 'E02CC25E00494185832C3A65DB755D01',
        major: sigfoxBLEData.major,
        minor: sigfoxBLEData.minor,
        rssi: sigfoxBLEData.rssi,
        timestamp: sigfoxRequestBody.time,
      } as ArgosSigfoxBLERequestBody
    }
  } else {
    if (type === '1f') {
      const sigfoxGPSData = parseGPSData(data)
      argosRequestbody = {
        type: 1,
        lat: sigfoxGPSData.lat,
        lon: sigfoxGPSData.lng,
        bat: sigfoxGPSData.bat,
        pdop: sigfoxGPSData.pdop,
        timestamp: sigfoxRequestBody.time,
      } as ArgosSigfoxGPSRequestBody
    } else {
      const failedData = parseFailedData(data)
      argosRequestbody = {
        type: 1,
        lat: sigfoxRequestBody.computedLocation.lat,
        lon: sigfoxRequestBody.computedLocation.lng,
        bat: failedData.bat,
        timestamp: sigfoxRequestBody.time,
        source: sigfoxRequestBody.computedLocation.source,
      } as ArgosSigfoxGPSRequestBody
    }
  }

  if (argosRequestbody) {
    const resArgos = await sendToArgosSigfox(
      headers,
      tenantId,
      argosRequestbody,
      stage
    )
    console.log(resArgos)
  }

  const response = {
    statusCode: 200,
    body: JSON.stringify({}),
  }
  return response
}
export { sigfoxHandler }
