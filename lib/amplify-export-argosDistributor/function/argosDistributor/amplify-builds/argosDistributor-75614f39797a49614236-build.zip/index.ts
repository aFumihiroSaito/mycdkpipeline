import {
  APIGatewayEvent,
  APIGatewayProxyHandler,
  APIGatewayProxyResult,
  Callback,
  Context,
} from 'aws-lambda'
import { grooveNautsHandler } from './handler/grooveNauts'
import { sigfoxHandler } from './handler/sigfox'

const handler: APIGatewayProxyHandler = async (
  event: APIGatewayEvent,
  context: Context,
  callback: Callback<APIGatewayProxyResult>
) => {
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 400,
      body: JSON.stringify({
        message:
          'postMethod only accepts POST method, you tried: ${event.httpMethod} method.',
      }),
    }
  }
  const tenantId = event.pathParameters && event.pathParameters.tenantId
  const handlerPath = event.path.replace(`/api/v1/${tenantId}/location/`, '')
  console.log(event.path)

  switch (handlerPath) {
    case 'soracom':
      await grooveNautsHandler(event, context, callback)
      break
    case 'sigfox':
      await sigfoxHandler(event, context, callback)
      break
    default:
      break
  }

  return {
    statusCode: 200,
    body: JSON.stringify({}),
  }
}
export { handler }
