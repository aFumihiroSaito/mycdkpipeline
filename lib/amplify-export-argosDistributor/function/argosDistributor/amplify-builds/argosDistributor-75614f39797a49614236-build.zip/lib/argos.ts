import crypto from 'crypto'

import { post } from './http'
import { ARGOS_HOST_DEV, ARGOS_HOST_PROD } from './constants'

export type ArgosSoracomRequestHeader = {
  'x-soracom-imei': string
  'x-soracom-imsi': string
  'x-soracom-signature': string
  'x-soracom-signature-version': string
  'x-soracom-timestamp': string
}

export type ArgosSigfoxRequestHeader = {
  'x-access-device-id': string
  'x-access-api-key': string
}

export type ArgosSoracomRequestBody = {
  type: number
  loc_data: string
  lat: number
  ns: string
  lon: number
  ew: string
  major_axis: number
  minor_axis: number
  bat: number
  uuid: string
  major: string
  minor: string
  rssi_b: string
  attr: number
  timestamp: string
  imei: string
  binaryParserEnabled: boolean
}

export type ArgosSigfoxGPSRequestBody = {
  type: number
  lat: number
  lon: number
  pdop: number
  source: number
  bat: number
  timestamp: number
}

export type ArgosSigfoxBLERequestBody = {
  type: number
  uuid: string
  major: number
  minor: number
  rssi: number
  bat: number
  timestamp: number
}

export const argosSoracomRequestHeader = (
  data: Record<string, any>
): ArgosSoracomRequestHeader => {
  return {
    'x-soracom-imei': data['x-soracom-imei'],
    'x-soracom-imsi': data['x-soracom-imsi'],
    'x-soracom-signature': data['x-soracom-signature'],
    'x-soracom-signature-version': data['x-soracom-signature-version'],
    'x-soracom-timestamp': data['x-soracom-timestamp'],
  }
}

export const validateHash = (data: Record<string, any>): boolean => {
  const signature = generateHash(data)
  return signature === data['x-soracom-signature']
}

export const generateHash = (data: Record<string, any>): string => {
  const key = 'nekoneko'
  return crypto
    .createHash('sha256')
    .update(
      `${key}x-soracom-imei=${data['x-soracom-imei']}x-soracom-imsi=${data['x-soracom-imsi']}x-soracom-timestamp=${data['x-soracom-timestamp']}`
    )
    .digest('hex')
}

export const sendToArgosSoracom = async (
  headers: ArgosSoracomRequestHeader,
  tenantId: string,
  proxyBody: Record<string, any> | string,
  env: 'dev' | 'prod'
): Promise<any> => {
  console.log(headers)
  console.log(proxyBody)

  return post(
    env === 'prod' ? ARGOS_HOST_PROD : ARGOS_HOST_DEV,
    `/api/v1/${tenantId}/location/soracom`,
    proxyBody,
    headers
  )
}

export const sendToArgosSigfox = async (
  headers: ArgosSigfoxRequestHeader,
  tenantId: string,
  proxyBody: Record<string, any> | string,
  env: 'dev' | 'prod'
): Promise<any> => {
  console.log(headers)
  console.log(proxyBody)

  return post(
    env === 'prod' ? ARGOS_HOST_PROD : ARGOS_HOST_DEV,
    `/api/v1/${tenantId}/location/sigfox`,
    proxyBody,
    headers
  )
}
