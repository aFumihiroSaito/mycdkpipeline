import aws from 'aws-sdk'
import { PromiseResult } from 'aws-sdk/lib/request'

export const getSigfoxAPIKey = async (): Promise<aws.SSM.ParameterList> => {
  const result: PromiseResult<aws.SSM.GetParametersResult, aws.AWSError> =
    await new aws.SSM()
      .getParameters({
        Names: ['SIGFOX_PROXY_API_KEY'].map(
          (secretName) => process.env[secretName]
        ),
        WithDecryption: true,
      })
      .promise()
  return result.Parameters
}
