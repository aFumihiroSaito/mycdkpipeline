export const ARGOS_HOST_DEV = 'https://argos.solomondev.access-company.com'
export const ARGOS_HOST_PROD = 'https://argos.solomon.access-company.com'
export const DISTRIBUTED_HOST =
  'https://magellan-iot-m6yksdy4-dot-blocks-gn-tanaka.appspot.com'
