import { post } from './http'
import { DISTRIBUTED_HOST } from './constants'

type DistributorRequestHeader = {
  'x-access-imei': string
  'x-access-imsi': string
  'x-access-timestamp': string
}

type Attributes = {
  type: number
  lat: number
  lon: number
  bat: number
  rs: number
  temp: number
  humi: number
  x: number
  y: number
  z: number
  imsi: string
  imei: string
  timestamp: number
}

type Log = {
  type: string
  attributes: Attributes
}

type DistributorRequestBody = {
  api_token: string
  logs: Log[]
}

export const distributorRequestHeader = (
  data: Record<string, any>
): DistributorRequestHeader => {
  return {
    'x-access-imsi': data['x-soracom-imsi'],
    'x-access-imei': data['x-soracom-imei'],
    'x-access-timestamp': data['x-soracom-timestamp'],
  }
}

export const distributorRequestBody = (
  headers: Record<string, any>,
  data: string
): DistributorRequestBody | null => {
  try {
    const parsedData = JSON.parse(data)
    const payload = parsedData.payload
    const stringified = Buffer.from(payload, 'base64').toString()
    const body = JSON.parse(stringified)
    return {
      api_token: '05c045dc226f5c355b815447',
      logs: [
        {
          type: 'gps_data',
          attributes: {
            type: body.type,
            lat: body.lat,
            lon: body.lon,
            bat: body.bat,
            rs: body.rs,
            temp: body.temp,
            humi: body.humi,
            x: body.x,
            y: body.y,
            z: body.z,
            imsi: headers['x-soracom-imsi'],
            imei: headers['x-soracom-imei'],
            timestamp: Math.trunc(
              parseInt(headers['x-soracom-timestamp']) / 1000
            ),
          },
        },
      ],
    }
  } catch (e) {
    console.error(e)
    return null
  }
}

export const sendToDistributor = async (
  headers: Record<string, any>,
  body: Record<string, any>
): Promise<any> => {
  console.log(JSON.stringify(body))

  return await post(DISTRIBUTED_HOST, '', body, headers)
}
