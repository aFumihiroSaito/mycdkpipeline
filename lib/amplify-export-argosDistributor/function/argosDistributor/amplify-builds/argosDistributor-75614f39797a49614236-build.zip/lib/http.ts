import rp from 'request-promise'

// Convenient request senders
export const get: any = async (
  host: string,
  path: string,
  token: Record<string, any>
) => sendRequest('GET', host, path, null, '', token)

export const post: any = async (
  host: string,
  path: string,
  body: any,
  token: Record<string, any>
) => sendRequest('POST', host, path, null, body, token)

export const sendRequest: any = async (
  method: string,
  host: string,
  path: string,
  queryParams: any,
  body: any,
  additionalHeader: Record<string, any>
) => {
  const reqBody = typeof body !== 'string' ? JSON.stringify(body) : body
  const baseHeaders = {
    ...additionalHeader,
    accept: 'application/json',
  }
  const reqHeaders =
    reqBody.length > 0
      ? Object.assign(baseHeaders, { 'content-type': 'application/json' })
      : baseHeaders
  return rp({
    method: method,
    uri: `${host}${path}`,
    body: reqBody,
    headers: reqHeaders,
    qs: queryParams,
    simple: false, // Reject only when requests failed with connection issues
    transform: jsonReader,
  }).catch(handleUnexpectedError)
}

const jsonReader = (
  body: string,
  { statusCode, headers }: { statusCode: number; headers: Record<string, any> }
) => {
  const isJson =
    headers['content-type'] &&
    headers['content-type'].startsWith('application/json')
  return { status: statusCode, body: isJson ? JSON.parse(body) : body }
}

const handleUnexpectedError = (error: any) => {
  return { status: 500, body: { message: error.message } }
}
