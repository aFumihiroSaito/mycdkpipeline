export type ComputedLocation = {
  lat: number
  lng: number
  radius: number
  source: number
  status: number
}

export type SigfoxRequestBody = {
  device: string
  deviceTypeId: string
  time: number
  data: string
  computedLocation: ComputedLocation
}

export type SigfoxFailedData = {
  type: string
  bat: number
}

export type SigfoxGPSData = {
  type: string
  bat: number
  lat: number
  lng: number
  magnet: number
  trip: number
  pdop: number
}

export type SigfoxBLEData = {
  type: string
  bat: number
  rssi: number
  major: number
  minor: number
  magnet: number
  trip: number
  numId: number
}

export type MajorMinor = {
  major: number
  minor: number
}

export const parseBLEData = (data: string): SigfoxBLEData | null => {
  // 8f 0064 2664 ba ffffff 24 21 00
  //24: 0010 1000
  const sendNumber = data.substr(22, 2)
  // TODO: merge message.
  if (sendNumber === '01') {
    console.log('message 01')
    return null
  }
  let rssi = parseInt(data.substr(10, 2), 16)
  if ((rssi & 0x80) > 0) {
    rssi = rssi - 0x100
  }
  const opt3 = parseInt(data.substr(20, 2), 16)
  const magnet = opt3 & 0xc0 // 11 000000
  const trip = opt3 & 0x38 // 00 111 000
  const numId = opt3 & 0x07 // 00 000 111
  return {
    type: data.substr(0, 2),
    major: parseInt(data.substr(2, 4), 16),
    minor: parseInt(data.substr(6, 4), 16),
    rssi,
    bat: parseInt(data.substr(18, 2), 16) / 10,
    magnet,
    trip,
    numId,
  }
}

export const parseGPSData = (data: string): SigfoxGPSData => {
  const opt = parseInt(data.substr(20, 2), 16)
  const magnet = opt & 0xc0 // 11 000000
  const trip = opt & 0x38 // 00 111 000
  const pdop = opt & 0x07 // 00 000 111
  return {
    type: data.substr(0, 2),
    lat: parseInt(data.substr(2, 8), 16) / 1000000,
    lng: parseInt(data.substr(10, 8), 16) / 1000000,
    bat: parseInt(data.substr(18, 2), 16) / 10,
    magnet,
    trip,
    pdop,
  }
}

export const parseFailedData = (data: string): SigfoxFailedData => {
  return {
    type: data.substr(0, 2),
    bat: parseInt(data.substr(2, 2), 16) / 10,
  }
}
